<template lang="pug">  
 .grid.grid-cols-2.gap-3     
   InputSelect(label="Proposal Status" name="city"  placeholder="Select Status"  )
   InputSelect(label="Assigned User" name="city"  placeholder="Select User"  )
 .grid.grid-cols-1.gap-3
   InputDate(label="Date Range" placeholder="Enter Date Range" )
</template>