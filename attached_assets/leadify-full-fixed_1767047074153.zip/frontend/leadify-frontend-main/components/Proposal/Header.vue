<template lang="pug">
div.flex.align-center.justify-between
  .appLogo: Logo
  .proposal-info
    p.text-sm.text-gray-400.font-medium.mb-2 Reference: #[span.text-black HI - PO - 1882024]
    p.text-sm.text-gray-400.font-medium.mb-4 Version: #[span.text-black 1.0]



</template>

<style lang="scss" scoped></style>
