<template>
  <div class="logo">
    <img class="w-[60px]" src="/images/Logo.png" alt="Logo" />
  </div>
</template>
