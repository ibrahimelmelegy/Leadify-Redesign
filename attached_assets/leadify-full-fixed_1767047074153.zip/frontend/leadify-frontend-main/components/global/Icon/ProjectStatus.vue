<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none">
    <path
      d="M1.8374 11.7266C2.6399 14.3066 4.79991 16.2941 7.48491 16.8416"
      stroke="#918E98"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M1.5376 8.735C1.9201 4.9475 5.1151 2 9.0001 2C12.8851 2 16.0801 4.955 16.4626 8.735"
      stroke="#918E98"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M10.5073 16.8506C13.1848 16.3031 15.3373 14.3381 16.1548 11.7656"
      stroke="#918E98"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
