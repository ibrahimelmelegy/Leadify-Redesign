<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
    <path
      d="M12.8255 4.34199L14.0004 6.69199C14.1588 7.01699 14.5838 7.32532 14.9421 7.39198L17.0671 7.74198C18.4255 7.96698 18.7421 8.95032 17.7671 9.93365L16.1088 11.592C15.8338 11.867 15.6755 12.4087 15.7671 12.8003L16.2421 14.8503C16.6171 16.467 15.7504 17.1003 14.3254 16.2503L12.3338 15.067C11.9754 14.8503 11.3754 14.8503 11.0171 15.067L9.02544 16.2503C7.60044 17.092 6.73378 16.467 7.10878 14.8503L7.58379 12.8003C7.67545 12.417 7.51712 11.8753 7.24212 11.592L5.58379 9.93365C4.60879 8.95865 4.92545 7.97531 6.28379 7.74198L8.40878 7.39198C8.76711 7.33365 9.19211 7.01699 9.35045 6.69199L10.5255 4.34199C11.1505 3.06699 12.1838 3.06699 12.8255 4.34199Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M6.66699 4.16699H1.66699"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M4.16699 15.833H1.66699"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path d="M2.50033 10H1.66699" stroke="#currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
  </svg>
</template>
