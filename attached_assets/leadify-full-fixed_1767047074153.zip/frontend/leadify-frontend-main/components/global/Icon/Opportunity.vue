<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
    <path
      d="M10.0001 6.5752L9.10838 8.1252C8.90838 8.46686 9.07505 8.7502 9.46672 8.7502H10.5251C10.9251 8.7502 11.0834 9.03353 10.8834 9.3752L10.0001 10.9252"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M6.91647 15.0332V14.0665C4.9998 12.9082 3.4248 10.6498 3.4248 8.24982C3.4248 4.12482 7.21647 0.891487 11.4998 1.82482C13.3831 2.24149 15.0331 3.49149 15.8915 5.21649C17.6331 8.71649 15.7998 12.4332 13.1081 14.0582V15.0248C13.1081 15.2665 13.1998 15.8248 12.3081 15.8248H7.71647C6.7998 15.8332 6.91647 15.4748 6.91647 15.0332Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.08301 18.333C8.99134 17.7913 11.008 17.7913 12.9163 18.333"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
