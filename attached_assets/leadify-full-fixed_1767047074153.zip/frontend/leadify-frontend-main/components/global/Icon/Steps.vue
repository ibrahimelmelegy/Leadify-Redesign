<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none">
    <path
      d="M11.25 12.166C14.1495 12.166 16.5 9.81551 16.5 6.91602C16.5 4.01652 14.1495 1.66602 11.25 1.66602C8.35051 1.66602 6 4.01652 6 6.91602C6 9.81551 8.35051 12.166 11.25 12.166Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
    />
    <path
      d="M6.75 16.666C9.6495 16.666 12 14.3155 12 11.416C12 8.51652 9.6495 6.16602 6.75 6.16602C3.85051 6.16602 1.5 8.51652 1.5 11.416C1.5 14.3155 3.85051 16.666 6.75 16.666Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
    />
  </svg>
</template>
