<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
    <path
      d="M6.66685 18.974H13.3335C16.6835 18.974 17.2835 17.6323 17.4585 15.999L18.0835 9.33229C18.3085 7.29896 17.7252 5.64062 14.1668 5.64062H5.83351C2.27518 5.64062 1.69185 7.29896 1.91685 9.33229L2.54185 15.999C2.71685 17.6323 3.31685 18.974 6.66685 18.974Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M6.6665 5.64193V4.97526C6.6665 3.50026 6.6665 2.30859 9.33317 2.30859H10.6665C13.3332 2.30859 13.3332 3.50026 13.3332 4.97526V5.64193"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M11.6668 11.474V12.3073C11.6668 12.3156 11.6668 12.3156 11.6668 12.324C11.6668 13.2323 11.6585 13.974 10.0002 13.974C8.35016 13.974 8.3335 13.2406 8.3335 12.3323V11.474C8.3335 10.6406 8.3335 10.6406 9.16683 10.6406H10.8335C11.6668 10.6406 11.6668 10.6406 11.6668 11.474Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M18.0415 9.80859C16.1165 11.2086 13.9165 12.0419 11.6665 12.3253"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M2.18311 10.0312C4.05811 11.3146 6.17477 12.0896 8.3331 12.3312"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
