<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none">
    <path
      d="M13.5 14.6453H12.93C12.33 14.6453 11.76 14.8778 11.34 15.2978L10.0575 16.5653C9.47248 17.1428 8.52001 17.1428 7.93501 16.5653L6.6525 15.2978C6.2325 14.8778 5.655 14.6453 5.0625 14.6453H4.5C3.255 14.6453 2.25 13.6478 2.25 12.4178V4.23529C2.25 3.00529 3.255 2.00781 4.5 2.00781H13.5C14.745 2.00781 15.75 3.00529 15.75 4.23529V12.4178C15.75 13.6403 14.745 14.6453 13.5 14.6453Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M9.00044 7.99986C9.96556 7.99986 10.748 7.21747 10.748 6.25235C10.748 5.28723 9.96556 4.50488 9.00044 4.50488C8.03532 4.50488 7.25293 5.28723 7.25293 6.25235C7.25293 7.21747 8.03532 7.99986 9.00044 7.99986Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M12 12.2448C12 10.8948 10.6575 9.7998 9 9.7998C7.3425 9.7998 6 10.8948 6 12.2448"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
