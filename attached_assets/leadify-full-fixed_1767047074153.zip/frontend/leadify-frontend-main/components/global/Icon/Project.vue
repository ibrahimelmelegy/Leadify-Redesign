<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
    <path
      d="M10.8416 2.43359L15.7583 4.61693C17.1749 5.24193 17.1749 6.27526 15.7583 6.90026L10.8416 9.08359C10.2833 9.33359 9.3666 9.33359 8.80827 9.08359L3.8916 6.90026C2.47493 6.27526 2.47493 5.24193 3.8916 4.61693L8.80827 2.43359C9.3666 2.18359 10.2833 2.18359 10.8416 2.43359Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M2.5 9.16699C2.5 9.86699 3.025 10.6753 3.66667 10.9587L9.325 13.4753C9.75833 13.667 10.25 13.667 10.675 13.4753L16.3333 10.9587C16.975 10.6753 17.5 9.86699 17.5 9.16699"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M2.5 13.333C2.5 14.108 2.95833 14.808 3.66667 15.1247L9.325 17.6413C9.75833 17.833 10.25 17.833 10.675 17.6413L16.3333 15.1247C17.0417 14.808 17.5 14.108 17.5 13.333"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
