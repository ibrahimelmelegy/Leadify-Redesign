<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
    <path
      d="M16.25 8.5166V15.8333C16.25 17.4999 15.8333 18.3333 13.75 18.3333H6.25C4.16667 18.3333 3.75 17.4999 3.75 15.8333V8.5166"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M4.16675 1.66699H15.8334C17.5001 1.66699 18.3334 2.50033 18.3334 4.16699V5.83366C18.3334 7.50033 17.5001 8.33366 15.8334 8.33366H4.16675C2.50008 8.33366 1.66675 7.50033 1.66675 5.83366V4.16699C1.66675 2.50033 2.50008 1.66699 4.16675 1.66699Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M8.4834 11.667H11.5167"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
