<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none">
    <path
      d="M16.5 6.36852V3.33852C16.5 2.14602 16.02 1.66602 14.8275 1.66602H11.7975C10.605 1.66602 10.125 2.14602 10.125 3.33852V6.36852C10.125 7.56102 10.605 8.04102 11.7975 8.04102H14.8275C16.02 8.04102 16.5 7.56102 16.5 6.36852Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.875 6.55602V3.15102C7.875 2.09352 7.395 1.66602 6.2025 1.66602H3.1725C1.98 1.66602 1.5 2.09352 1.5 3.15102V6.54852C1.5 7.61352 1.98 8.03352 3.1725 8.03352H6.2025C7.395 8.04102 7.875 7.61352 7.875 6.55602Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.875 14.9935V11.9635C7.875 10.771 7.395 10.291 6.2025 10.291H3.1725C1.98 10.291 1.5 10.771 1.5 11.9635V14.9935C1.5 16.186 1.98 16.666 3.1725 16.666H6.2025C7.395 16.666 7.875 16.186 7.875 14.9935Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path d="M11.25 11.791H15.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
    <path d="M11.25 14.791H15.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
  </svg>
</template>
