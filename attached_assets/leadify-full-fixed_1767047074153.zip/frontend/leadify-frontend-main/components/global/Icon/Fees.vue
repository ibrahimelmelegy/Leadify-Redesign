<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none">
    <path
      d="M14.4752 6.4406V10.3031C14.4752 12.6131 13.1552 13.6031 11.1752 13.6031H4.58271C4.24521 13.6031 3.92271 13.5731 3.62271 13.5056C3.43521 13.4756 3.25522 13.4231 3.09022 13.3631C1.96522 12.9431 1.28271 11.9681 1.28271 10.3031V6.4406C1.28271 4.1306 2.60271 3.14062 4.58271 3.14062H11.1752C12.8552 3.14062 14.0627 3.85312 14.3852 5.48062C14.4377 5.78062 14.4752 6.0881 14.4752 6.4406Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M16.726 8.69044V12.553C16.726 14.863 15.406 15.8529 13.426 15.8529H6.83353C6.27853 15.8529 5.77604 15.778 5.34104 15.613C4.44854 15.283 3.84104 14.6005 3.62354 13.5055C3.92354 13.573 4.24603 13.6029 4.58353 13.6029H11.176C13.156 13.6029 14.476 12.613 14.476 10.303V6.44044C14.476 6.08794 14.446 5.77297 14.386 5.48047C15.811 5.78047 16.726 6.78544 16.726 8.69044Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.87405 10.3546C8.96758 10.3546 9.85406 9.46807 9.85406 8.37454C9.85406 7.28102 8.96758 6.39453 7.87405 6.39453C6.78053 6.39453 5.89404 7.28102 5.89404 8.37454C5.89404 9.46807 6.78053 10.3546 7.87405 10.3546Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M3.58545 6.72656V10.0266"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M12.1665 6.72656V10.0266"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
