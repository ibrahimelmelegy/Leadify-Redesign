<template>
  <svg
    width="20"
    height="21"
    viewBox="0 0 20 21"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M17.5 6.47526V14.8086C17.5 17.3086 16.25 18.9753 13.3333 18.9753H6.66667C3.75 18.9753 2.5 17.3086 2.5 14.8086V6.47526C2.5 3.97526 3.75 2.30859 6.66667 2.30859H13.3333C16.25 2.30859 17.5 3.97526 17.5 6.47526Z"
      stroke="#3F3A4D"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M12.0834 4.39062V6.05729C12.0834 6.97396 12.8334 7.72396 13.75 7.72396H15.4167"
      stroke="#3F3A4D"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M6.66663 11.4727H9.99996"
      stroke="#3F3A4D"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M6.66663 14.8086H13.3333"
      stroke="#3F3A4D"
      stroke-width="1.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
