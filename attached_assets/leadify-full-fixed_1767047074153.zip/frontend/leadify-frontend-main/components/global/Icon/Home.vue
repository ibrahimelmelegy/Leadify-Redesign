<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
    <path
      d="M7.49996 18.9733H12.5C16.6666 18.9733 18.3333 17.3066 18.3333 13.14V8.13997C18.3333 3.97331 16.6666 2.30664 12.5 2.30664H7.49996C3.33329 2.30664 1.66663 3.97331 1.66663 8.13997V13.14C1.66663 17.3066 3.33329 18.9733 7.49996 18.9733Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M12.9167 16.056C13.8333 16.056 14.5833 15.306 14.5833 14.3893V6.88932C14.5833 5.97266 13.8333 5.22266 12.9167 5.22266C12 5.22266 11.25 5.97266 11.25 6.88932V14.3893C11.25 15.306 11.9917 16.056 12.9167 16.056Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.08329 16.0566C7.99996 16.0566 8.74996 15.3066 8.74996 14.39V11.4733C8.74996 10.5566 7.99996 9.80664 7.08329 9.80664C6.16663 9.80664 5.41663 10.5566 5.41663 11.4733V14.39C5.41663 15.3066 6.15829 16.0566 7.08329 16.0566Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
