<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17" fill="none">
    <path
      d="M8.00016 15.1654C11.6668 15.1654 14.6668 12.1654 14.6668 8.4987C14.6668 4.83203 11.6668 1.83203 8.00016 1.83203C4.3335 1.83203 1.3335 4.83203 1.3335 8.4987C1.3335 12.1654 4.3335 15.1654 8.00016 15.1654Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path d="M5.1665 8.49995L7.05317 10.3866L10.8332 6.61328" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
  </svg>
</template>
