<template lang="pug">
    div
      ProposalFinanceTable(:loading="loading" label="Finance Table")
</template>
    
<script lang="ts" setup>

const isLoading = ref(false);
    
</script>
    
<style lang="scss"></style>
    