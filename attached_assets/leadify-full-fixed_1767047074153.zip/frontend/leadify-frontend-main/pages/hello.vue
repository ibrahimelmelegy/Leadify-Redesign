<template lang="pug">
.relative
    p test reloading
</template>
