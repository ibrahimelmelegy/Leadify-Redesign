<template lang="pug">
.container
    slot
</template>

<script setup></script>

<style lang="scss"></style>
