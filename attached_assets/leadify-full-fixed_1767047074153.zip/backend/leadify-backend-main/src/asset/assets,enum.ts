export enum AssetSortByEnum {
  name = 'name',
  rentPrice = 'rentPrice',
  buyPrice = 'buyPrice'
}
