export const constants = {
  defaultServerResponse: {
    status: 400,
    success: false,
    message: "",
    body: {},
  },
  public: {
    DONE_SUCCESSFULLY: "Operation Done Successfully",
  },
};
