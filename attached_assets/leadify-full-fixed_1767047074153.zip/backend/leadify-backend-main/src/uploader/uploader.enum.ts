export enum FileModel {
  PROJECT = 'PROJECT',
  USER = 'USER',
  PROPOSAL = 'PROPOSAL',
  CLIENT = 'CLIENT',
  SETTING = 'SETTING'
}
