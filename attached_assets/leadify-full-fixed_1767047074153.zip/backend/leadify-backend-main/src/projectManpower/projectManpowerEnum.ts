export enum MissionEnum {
  Standard = 1,
  Helper = 0.5,
  SiteEngineer = 1,
  Engineer = 1
}
