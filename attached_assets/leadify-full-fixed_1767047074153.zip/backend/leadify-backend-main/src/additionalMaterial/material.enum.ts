export enum MaterialSortByEnum {
  rentCost = 'rentCost',
  gasCost = 'gasCost',
  oilCost = 'oilCost'
}
