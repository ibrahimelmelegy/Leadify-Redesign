export enum manufacturerVehicle {
  Sedan = 'Sedan',
  Changan_Hunter = 'Changan Hunter',
  Other = 'Other'
}

export enum VehicleSortByEnum {
  rentCost = 'rentCost',
  gasCost = 'gasCost',
  oilCost = 'oilCost'
}
